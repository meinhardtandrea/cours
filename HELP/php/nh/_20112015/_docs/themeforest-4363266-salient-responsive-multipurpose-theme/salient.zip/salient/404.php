<?php get_header(); ?>

<div class="container-wrap">
	
	<div class="container main-content">
		
		<div class="row">
			
			<div class="col span_12">
				
				<div id="error-404">
					<h1>404</h1>
					<h2><?php echo __('Not Found.', NECTAR_THEME_NAME); ?></h2>
				</div>
				
			</div><!--/span_12-->
			
		</div><!--/row-->
		
	</div><!--/container-->

</div>
<?php get_footer(); ?>

